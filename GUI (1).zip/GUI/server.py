from waitress import serve
from  import app

serve(app, host='0.0.0.0', port=443, url_scheme='https')
