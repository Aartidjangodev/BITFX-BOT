from flask import Flask
from gevent.pywsgi import WSGIServer

app = Flask(__name__)

@app.route('/api', methods=['GET'])
def index():
    return "Hello, World!"

if __name__ == '__main__':
    try:
        http_server = WSGIServer(('0.0.0.0', 5000), app)
        print("Server started successfully.")
        http_server.serve_forever()
    except Exception as e:
        print("Error:", e)

